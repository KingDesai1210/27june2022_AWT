$(document).ready(function(){
    $('#1').click(function(){
        $("#01").hide(500);

    });
    $('#2').click(function(){
        $("#01").show(500);
    });
    $('#3').click(function(){
        $("#01").height(500);
        $("#01").width(500);
    });
    $('#4').click(function(){
        $('#01').height(100);
        $('#01').width(100);
    })
});