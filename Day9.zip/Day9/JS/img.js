function Image(){
    document.getElementById('fd').onclick('')
}