function changefont(){
    document.getElementById('01').style.fontFamily="firstfont"
}
function changesize(){
    document.getElementById('01').style.fontSize="60px";

}
function hide(){
    document.getElementById('01').style.display="none"
}