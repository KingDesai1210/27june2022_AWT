

function External(){
    alert('Externaljs');
    console.log('kingdesai');
    document.getElementById('kd').style.backgroundColor=prompt("enter your color");
    document.body.style.backgroundColor="blue"
    document.getElementById('kd1').style.backgroundColor="orange";
    document.getElementById('kd2').style.backgroundColor="yellow";
    

}
function DF(){
    // document.body.style.backgroundColor=document.getElementById('DD').value;
    document.getElementById('fd').style.backgroundColor=document.getElementById('DD').value;
}
function colour52(){
var ddd=prompt('enter your name');
document.getElementById("fdd").innerHTML=ddd

var dad=prompt('enter your name');
document.getElementById("fdd2").innerHTML=dad
}