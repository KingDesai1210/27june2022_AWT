$(document).ready(function(){
    $("#01").draggable();
    $("#02").droppable({
        accept: "#01",
        drop:function(event,ui) {
            $(this).find("p").html("Done...");
        }
        })
})